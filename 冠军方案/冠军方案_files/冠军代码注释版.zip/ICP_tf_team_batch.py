# -*- coding: utf-8 -*-
"""
Created on Thu Aug 19 16:01:00 2021

@author: kmat
"""
import tensorflow as tf
import numpy as np
from scipy.optimize import linear_sum_assignment
import matplotlib.pyplot as plt


def transform_points(transmatrix, points):
    x, y = tf.split(points, 2, axis=-1)
    xyones = tf.concat([x,y,tf.ones_like(x)], axis=-1)
    trans_points = tf.matmul(xyones, transmatrix, transpose_b=True)[...,:2]
    return trans_points

def get_nearest_distance(sources, targets):
    dist_matrix = tf.reduce_sum((sources[:,tf.newaxis,:] - targets[tf.newaxis,:,:])**2, axis=-1)
    dist_to_near_target = tf.reduce_min(dist_matrix, axis=1)
    dist_to_near_source = tf.reduce_min(dist_matrix, axis=0)
    return dist_to_near_target, dist_to_near_source

def search_nearest_error(sources, targets):
    #[batch, num_source, num_target]
    dist_matrix = tf.reduce_sum((sources[tf.newaxis,:,tf.newaxis,:] - targets[tf.newaxis,tf.newaxis,:,:])**2, axis=-1)
    assignments = tf_linear_sum_assignment_batch(dist_matrix)[0]
    assigned_targets = tf.gather(targets, assignments)

    target_idx = tf.cast(tf.range(tf.shape(targets)[0])[:,tf.newaxis], tf.float32)
    assigned_index = tf.cast(assignments, tf.float32)[tf.newaxis,:]
    not_assigned_idx_target = tf.boolean_mask(target_idx[:,0], 
                                              tf.reshape(tf.reduce_all(target_idx != assigned_index, axis=-1), [tf.shape(targets)[0],]))
    not_assigned_targets = tf.gather(targets, tf.cast(not_assigned_idx_target, tf.int32))
    error = tf.reduce_mean(tf.reduce_sum((sources - assigned_targets)**2, axis=-1))
    return error, assigned_targets, assignments, not_assigned_targets

def random_circle_search(targets, sources, num_try):
    '''
    给定targets点坐标和sources点坐标，及实验次数num_try
    在包围targets、且平行于坐标轴的最小长方形内，随机选取100个点作为圆心，以sources距离原点的最大距离作为半径
    若targets落在圆心内点的数量接近sources点的数量，则选取该圆心作为候选的x平移量和y平移量
    :param targets:
    :param sources:
    :param num_try:
    :return:
    '''
    # sources: (k1, 2)
    # targets: (k2, 2)
    # randomly search the area whose number of targets are same as the source
    num_points, _ = tf.unstack(tf.shape(sources))

    base_radius = tf.math.sqrt(tf.reduce_max(tf.reduce_sum(sources[...,:2]**2, axis=-1))) # source中距离原点最远的距离
    # 包围targets的最小长方体的左下顶点和右上顶点
    targets_xy_min = tf.reduce_min(targets[...,:2], axis=0)
    targets_xy_max = tf.reduce_max(targets[...,:2], axis=0)

    # centers相当于是在targets对应的长方体区域内均匀随机选取100个中点
    centers = tf.random.uniform((num_try, 2), minval=targets_xy_min, maxval=targets_xy_max)
    radius = base_radius * tf.math.exp(tf.random.uniform((num_try,), -0.25, 0.25))
    # [0.778, 1.284] * base_radius, (100, )
    # 计算centers中第i个点相对targets中第j个点的距离，dists_from_centers：(100, 22)
    dists_from_centers = tf.math.sqrt(tf.reduce_sum((targets[tf.newaxis,:,:] - centers[:,tf.newaxis,:])**2, axis=-1))
    # 以每组实验的center为圆心，0.778r-1.284r为半径，落在半径内targets的数量，如果接近sources的点数量，则该圆心称为候选的x、y偏移量
    num_inside_circle = tf.reduce_sum(tf.cast(dists_from_centers < radius[:,tf.newaxis], tf.int32), axis=1)
    ok_mask = tf.math.logical_and(num_points-2<=num_inside_circle, num_inside_circle<=num_points+2)
    centers = tf.boolean_mask(centers, ok_mask)
    return centers


def points2points_fitting(targets, sources, num_iter=6, l2_reg=0.1, rot_init=0.):
    
    def get_transmatrix(k, rz, tx, ty):
        """
        k : zoom ratio.
        rz : rotation.
        tx : x offset.
        ty : z offset
        shape [batch]
        
        returns:
            transmatrix with shape [batch, 3, 3]
        """
        exp_k = tf.math.exp(k)
        sin = tf.math.sin(rz)
        cos = tf.math.cos(rz)
        mat = tf.stack([[exp_k*cos, -exp_k*sin, exp_k*tx],
                        [exp_k*sin, exp_k*cos, exp_k*ty],
                        [tf.zeros_like(k), tf.zeros_like(k), tf.ones_like(k)]])
        mat = tf.transpose(mat, [2,0,1])
        return mat
        
    def transform_points(transmatrix, points):
        x, y = tf.split(points, 2, axis=-1)
        xyones = tf.concat([x,y,tf.ones_like(x)], axis=-1)
        trans_points = tf.matmul(xyones, transmatrix, transpose_b=True)[...,:2]
        return trans_points
    
    def get_derivative_at(k, rz, tx, ty, points):
        dev = 1e-5
        original = transform_points(get_transmatrix(k, rz, tx, ty), points)
        dxy_dk = (transform_points(get_transmatrix(k+dev, rz, tx, ty), points) - original) / dev
        dxy_drz = (transform_points(get_transmatrix(k, rz+dev, tx, ty), points) - original) / dev
        dxy_dtx = (transform_points(get_transmatrix(k, rz, tx+dev, ty), points) - original) / dev
        dxy_dty = (transform_points(get_transmatrix(k, rz, tx, ty+dev), points) - original) / dev
        return original, dxy_dk, dxy_drz, dxy_dtx, dxy_dty
    
    def normal_equation(X, Y, gn_rate=0.9, gd_rate=0.1):
        #not in use
        #Gaussian Neuton combind with Gradient descent
        XtX = tf.matmul(X, X, transpose_a=True)
        #XtX_inv = np.linalg.inv(XtX)
        #XtX_inv = 1.0*XtX_inv + 0.5*np.eye(len(XtX))
        #results = np.dot(XtX_inv, np.dot(X.T, Y))
        
        results_neuton = tf.linalg.solve(XtX, tf.matmul(X, Y, transpose_a=True))
        results_gaussian = tf.matmul(tf.tile(tf.eye(XtX.shape[1])[tf.newaxis,...], [XtX.shape[0],1,1]), tf.matmul(X, Y, transpose_a=True))
        results = gn_rate*results_neuton + gd_rate*results_gaussian
        
        return results
    
    # initial_values
    batch, num_points = tf.unstack(tf.shape(targets))[:2]
    k = 0.0 * tf.ones((batch), tf.float32)#expで取る。ネガティブでんし。
    rz = rot_init * tf.ones((batch), tf.float32)
    tx = 0.0 * tf.ones((batch), tf.float32)
    ty = 0.0 * tf.ones((batch), tf.float32)
    
    source_origin = sources
    for i in range(num_iter):
        currents, dxy_dk, dxy_rz, dxy_dtx, dxy_dty = get_derivative_at(k, rz, tx, ty, source_origin)
        b = tf.reshape(targets-currents, [batch, num_points*2, 1])#xy flatten
        a = tf.stack([dxy_dk, dxy_rz, dxy_dtx, dxy_dty], axis=-1)
        a = tf.reshape(a, [batch, num_points*2, 4])
        updates = tf.linalg.lstsq(a, b, l2_regularizer=l2_reg, fast=True)#batch, 4, 1
        
        k = k + updates[:,0,0]
        rz = rz + updates[:,1,0]
        tx = tx + updates[:,2,0]
        ty = ty + updates[:,3,0]
    trans_matrix = get_transmatrix(k, rz, tx, ty)
    trans_sources = transform_points(trans_matrix, sources)
    return trans_sources, trans_matrix, k, rz, tx, ty


@tf.function(input_signature=(tf.TensorSpec(shape=[None, 2], dtype=tf.float32),
                              tf.TensorSpec(shape=[None, 2], dtype=tf.float32),
                              tf.TensorSpec(shape=[None], dtype=tf.float32),
                              tf.TensorSpec(shape=[None, 1], dtype=tf.float32),
                              tf.TensorSpec(shape=[None, 1], dtype=tf.float32),
                              tf.TensorSpec(shape=[], dtype=tf.int32),
                              tf.TensorSpec(shape=[], dtype=tf.bool),
                              tf.TensorSpec(shape=[], dtype=tf.bool),
                              tf.TensorSpec(shape=[], dtype=tf.bool),
                              tf.TensorSpec(shape=[], dtype=tf.bool),
                              tf.TensorSpec(shape=[3], dtype=tf.float32),
                              tf.TensorSpec(shape=[3], dtype=tf.float32),
                              tf.TensorSpec(shape=[2,3], dtype=tf.float32),
                              tf.TensorSpec(shape=[], dtype=tf.float32),##増やした
                              )
             )
def make_icp_inputs(targets, 
                       sources,
                       confidence,
                       targets_team,
                       sources_team, 
                       num_trial,
                       is_sideline=True,#Sideline or Endzone
                       team_provided=False,
                       use_provided_params = False,
                       use_random_params = True,
                       zoom_params = tf.zeros((3), tf.float32),
                       rz_params = tf.zeros((3), tf.float32),#[0.0, 0.5, 0.01],#mean, std, l2 penalty
                       txy_params = tf.zeros((2,3), tf.float32),
                       confidence_threshold = 0.0,
                       team_weight = 0.1):
    '''
    给定targets点的坐标、队伍、视角，sources点的坐标、队伍、置信度，
    将sources点云的中心变换到原点，将除以10后的team得分设置为sources点的第三个维度，除以10后的team标签设置为targets点的第三个维度，
    如果use_provided_params=True，则使用传入的给定参数形成100次icp变换的初始变换参数，
    如果use_provided_params=False，则根据两组点云间的统计和位置关系，得到100次icp变换的初始变换参数。
    '''
    centering_by_circle = True

    # 为作为距离计算的第三个维度做准备
    targets_team = targets_team * team_weight
    sources_team = sources_team * team_weight
    
    valid_mask = confidence > confidence_threshold
    all_invalid_mask = confidence > 1.0
    
    # center調整，将sources中心移动到原点
    s_mean = tf.reduce_mean(sources, axis=0, keepdims=True)
    sources = sources - s_mean
    
    # 根据不同情况，制定不同的缩放参数和旋转参数
    if is_sideline:
        mean_k = 0.0
        sigma_k = 0.5
        min_rz_0 = -0.6 # -34.5度
        max_rz_0 = 0.6  # 34.5度
        min_rz_1 = np.pi - 0.6  # 145.5度
        max_rz_1 = np.pi + 0.6  # 214.5度, 跟-34.5至34.5是镜像对称，保证实验能够照顾到一个方向两种摄像角度的问题
        txty_std_t = tf.math.reduce_std(targets, axis=0)
        txty_std_s = tf.math.reduce_std(sources, axis=0)
        dev_std = tf.math.abs(txty_std_t - txty_std_s)
        std_tx = dev_std[0] + 0.05
        std_ty = dev_std[1] + 0.05
        mean_k = (tf.math.log(tf.reduce_sum(txty_std_t**2) / tf.reduce_sum(txty_std_s**2)))/2.0
        
    else:
        mean_k = 0.0
        sigma_k = 0.5
        min_rz_0 = -0.6 + np.pi/2 # 55.5
        max_rz_0 = 0.6 + np.pi/2  # 124.5
        min_rz_1 = -0.6 - np.pi/2 # 235.5
        max_rz_1 = 0.6 - np.pi/2  # 304.5，与sideline同理，照顾到了两个方向，同时在sideline基础上多转了90度
        txty_std_t = tf.math.reduce_std(targets, axis=0) # [std_x, std_y], targets中x坐标和y坐标的标准差
        txty_std_s = tf.math.reduce_std(sources, axis=0) # [std_x', std_y'], sources中x坐标和y坐标的标准差
        dev_std = tf.math.abs(txty_std_t - txty_std_s)
        std_tx = dev_std[0] + 0.05
        std_ty = dev_std[1] + 0.05
        mean_k = (tf.math.log(tf.reduce_sum(txty_std_t**2) / tf.reduce_sum(txty_std_s**2)))/2.0  # ？？？为什么
 
    rz_mean = rz_params[0]
    rz_std = rz_params[1]
    rz_penalty = rz_params[2]

    if use_provided_params:
        #rz = tf.random.normal([num_trial], rz_mean, rz_std, tf.float32)
        rz = tf.random.uniform([num_trial], rz_mean-rz_std, rz_mean+rz_std, tf.float32)
        rz_penalty = rz_penalty
        #provided_xy = tf.reduce_mean(targets, axis=0, keepdims=True)

        #"""
        mean_tx = txy_params[0,0]
        mean_ty = txy_params[1,0]
        std_tx = txy_params[0,1]
        std_ty = txy_params[1,1]
        tx_penalty = txy_params[0,2]
        ty_penalty = txy_params[1,2]
        
        mean_k = zoom_params[0]
        sigma_k = zoom_params[1]
        k_penalty = zoom_params[2]
        
    else:
        rz_0 = tf.random.uniform([num_trial//2], min_rz_0, max_rz_0, tf.float32)        
        rz_1 = tf.random.uniform([num_trial-num_trial//2], min_rz_1, max_rz_1, tf.float32)
        rz = tf.concat([rz_0, rz_1], axis=0)
        rz_penalty = 1.0


        t_mean = tf.reduce_mean(targets, axis=0, keepdims=True)
        mean_tx = t_mean[0,0]  # targets mean x，因为sources的中心已经归一到了原点，所以targets x坐标的均值就是sources该偏移的量，y轴同理
        mean_ty = t_mean[0,1]  # targets mean y
        tx_penalty = 1.0
        ty_penalty = 1.0
        k_penalty = 1.0

    # 如果提供了给定的参数，则按给定的参数设定缩放和平移变换的分布
    # 如果没提供给定的参数，则按当前情况计算合适的缩放及平移变换的分布
    k = tf.random.normal([num_trial], mean_k, sigma_k, tf.float32) # 缩放系数
    tx = tf.random.normal([num_trial], mean_tx, std_tx, tf.float32) # 以targets x轴平均值作为期望，targets与sources x轴标准差的差值+0.05作为标准差
    ty = tf.random.normal([num_trial], mean_ty, std_ty, tf.float32)        
    
    if centering_by_circle:
        if use_random_params:
            # 从包围targets点云的最小长方形内均匀生成100个点作为中点，选取这些中点中满足要求的点作为x轴平移量和y轴平移量
            txty_circle = random_circle_search(targets, sources, num_trial)
            num_points_circle, _ = tf.unstack(tf.shape(txty_circle))
            #tx = tf.concat([txty_circle[:,0], tx[:(num_trial-num_points_circle)]], axis=0)
            #ty = tf.concat([txty_circle[:,1], ty[:(num_trial-num_points_circle)]], axis=0)
            # half at maximum
            num_points_circle = tf.minimum(num_points_circle, num_trial//2)
            tx = tf.concat([txty_circle[:num_points_circle,0], tx[:(num_trial-num_points_circle)]], axis=0)
            ty = tf.concat([txty_circle[:num_points_circle,1], ty[:(num_trial-num_points_circle)]], axis=0)
    #tx = tf.random.uniform([], min_tx, max_tx, tf.float32)
    #ty = tf.random.uniform([], min_ty, max_ty, tf.float32)

    # 中央サンプル多め。OK？面積均一の方がいいかな？
    #radius = tf.random.uniform([], 0., farthest_dist, tf.float32)
    #angle = tf.random.uniform([], -np.pi, np.pi, tf.float32)
    #tx = radius * tf.math.sin(angle)
    #ty = radius * tf.math.cos(angle)
    # 将team信息贴在xy坐标后面，并扩展到100次实验
    targets = tf.concat([targets, tf.reshape(targets_team, [-1,1])], axis=-1) # (22, 3)
    targets = tf.tile(targets[tf.newaxis,...], [num_trial, 1, 1])  # (100, 22, 3)
    
    #concat team label (third axis)
    #現状、ソースは非固定ランダム。
    sources_team = tf.reshape(sources_team, [1,-1,1]) # (1, num_box, 1)
    
    if not team_provided:
        team_pos_neg = tf.cast(tf.random.uniform([num_trial,1,1], 0., 1., tf.float32)>0.5, tf.float32)  # (100, 1, 1)
        sources_team = sources_team * team_pos_neg + (team_weight-sources_team) * (1.-team_pos_neg)  # (100, num_box, 1)
        # 将source_team扩展到100次实验，在这100次实验中，随机选一些实验i，使得source_team[i]是以原本的使得source_team表达
        # 另外一些实验，则用1-source_team表达
    else:
        sources_team = tf.tile(sources_team, [num_trial, 1, 1])
    
    sources = tf.tile(sources[tf.newaxis,...], [num_trial, 1, 1]) # (100, num_box, 2)
    #sources_team = tf.ones_like(sources)[...,:1]
    sources = tf.concat([sources, sources_team], axis=-1)  # (100, num_box, 3)
    #sources = tf.reshape(sources, [num_trial,-1,3])
    
    ##sources = tf.concat([sources, tf.reshape(sources_team, [-1,1])], axis=-1)
    ##sources = tf.tile(sources[tf.newaxis,...], [num_trial, 1, 1])

    l2_penalty = tf.stack([[k_penalty, rz_penalty, tx_penalty, ty_penalty]])
    l2_penalty = tf.tile(l2_penalty, [num_trial, 1])[...,tf.newaxis] # (100, 4, 1)
    
    #current_sources, current_matrix, current_redisual, current_assignment, current_raw_results = icp_fitting_2d_batch(targets, sources, valid_mask, num_iter=num_fitting_iter, batch_size=num_trial,
    #                                                                      k = k, rz = rz, tx = tx, ty = ty, 
    #         
    #"""
    return targets, sources, valid_mask, all_invalid_mask, k, rz, tx, ty, l2_penalty

@tf.function(input_signature=(tf.TensorSpec(shape=[None, None, 3], dtype=tf.float32),
                              tf.TensorSpec(shape=[None, None, 3], dtype=tf.float32),

                              tf.TensorSpec(shape=[None], dtype=tf.bool),
                              tf.TensorSpec(shape=[None], dtype=tf.bool),

                              tf.TensorSpec(shape=[None], dtype=tf.float32),
                              tf.TensorSpec(shape=[None], dtype=tf.float32),
                              tf.TensorSpec(shape=[None], dtype=tf.float32),
                              tf.TensorSpec(shape=[None], dtype=tf.float32),

                              tf.TensorSpec(shape=[None, 4, 1], dtype=tf.float32),

                              tf.TensorSpec(shape=[None, None], dtype=tf.float32),

                              tf.TensorSpec(shape=[], dtype=tf.int32),
                              tf.TensorSpec(shape=[], dtype=tf.int32),
                              tf.TensorSpec(shape=[], dtype=tf.int32),
                              )
             )
def random_icp_fitting(targets, 
                       sources,
                       valid_mask, all_invalid_mask,
                       k, rz, tx, ty,
                       l2_penalty,
                       st_cost_matrix, 
                       num_fitting_iter=20,
                       num_harddrop = 0,
                       num_softdrop=0,
                       ):
    try_drop = True
    
    
    
    current_sources, current_matrix, current_redisual, current_assignment, current_raw_results, current_source_selection, current_residual_xy = icp_fitting_2d_batch_confdrop_cost(targets, sources, valid_mask, cost=st_cost_matrix, num_iter=num_fitting_iter,
                                                                          k = k, rz = rz, tx = tx, ty = ty, 
                                                                          l2_penalty=l2_penalty,
                                                                          num_harddrop=num_harddrop, num_softdrop=num_softdrop)
    # length of assignment is shorter than sources, due to harddrop
    best_idx = tf.argmin(current_redisual)
    current_sources = tf.gather(current_sources, best_idx)
    current_matrix = tf.gather(current_matrix, best_idx)
    current_redisual = tf.gather(current_redisual, best_idx)
    current_assignment = tf.gather(current_assignment, best_idx)
    current_source_selection = tf.gather(current_source_selection, best_idx)
    current_residual_xy = tf.gather(current_residual_xy, best_idx)
    current_raw_results = [tf.gather(x, best_idx) for x in current_raw_results]
    #"""


    
    if try_drop and (tf.math.log(current_redisual)>-6.):#TEMP-7.):#drop up to 20%
        num_drop = tf.maximum(0, tf.shape(sources)[1]//5)#icp_fitting_func, icp_fitting_2d_batch_drop##, drop_residual_xy 
        num_drop = tf.minimum(2, num_drop)
        drop_sources, drop_matrix, drop_redisual, drop_assignment, drop_raw_results, drop_source_selection, drop_residual_xy = icp_fitting_2d_batch_confdrop_cost(targets, sources, all_invalid_mask, cost=st_cost_matrix, num_iter=num_fitting_iter,
                                                                          k = k, rz = rz, tx = tx, ty = ty, 
                                                                          l2_penalty=l2_penalty,
                                                                          num_harddrop=num_harddrop, num_softdrop=num_drop+num_softdrop)
    
        best_idx = tf.argmin(drop_redisual)
        drop_redisual = tf.gather(drop_redisual, best_idx)
        if (tf.math.log(current_redisual) - tf.math.log(drop_redisual))>1.0:
            #print("DROP!")
            current_redisual = drop_redisual
            current_sources = tf.gather(drop_sources, best_idx)
            current_matrix = tf.gather(drop_matrix, best_idx)
            current_assignment = tf.gather(drop_assignment, best_idx)
            current_source_selection = tf.gather(drop_source_selection, best_idx)
            current_residual_xy = tf.gather(drop_residual_xy, best_idx)

            current_raw_results = [tf.gather(x, best_idx) for x in drop_raw_results]
    
    if try_drop and (tf.math.log(current_redisual)>-3.):#TEMP>-5.):#still bad
        num_drop = tf.maximum(0, tf.shape(sources)[1]//3)#icp_fitting_func, icp_fitting_2d_batch_drop##, drop_residual_xy 
        num_drop = tf.minimum(4, num_drop)
        drop_sources, drop_matrix, drop_redisual, drop_assignment, drop_raw_results, drop_source_selection, drop_residual_xy = icp_fitting_2d_batch_confdrop_cost(targets, sources, all_invalid_mask, cost=st_cost_matrix, num_iter=num_fitting_iter,
                                                                          k = k, rz = rz, tx = tx, ty = ty, 
                                                                          l2_penalty=l2_penalty,
                                                                          num_harddrop=num_harddrop, num_softdrop=num_drop+num_softdrop)
    
        best_idx = tf.argmin(drop_redisual)
        drop_redisual = tf.gather(drop_redisual, best_idx)
        if (tf.math.log(current_redisual) - tf.math.log(drop_redisual))>1.0:
            #print("DROP!")
            current_redisual = drop_redisual
            current_sources = tf.gather(drop_sources, best_idx)
            current_matrix = tf.gather(drop_matrix, best_idx)
            current_assignment = tf.gather(drop_assignment, best_idx)
            current_source_selection = tf.gather(drop_source_selection, best_idx)
            current_residual_xy = tf.gather(drop_residual_xy, best_idx)

            current_raw_results = [tf.gather(x, best_idx) for x in drop_raw_results]
    
    
    
    current_source_selection = tf.cast(current_source_selection, tf.bool)

    #print(current_redisual)

    return current_redisual, current_matrix, current_sources, current_assignment, current_raw_results, current_source_selection, current_residual_xy




def tf_linear_sum_assignment(cost_matrix):
    def np_linear_sum_assignment(cost_matrix):
        return linear_sum_assignment(cost_matrix, maximize=False)[1].astype(np.int32)
    return tf.numpy_function(func=np_linear_sum_assignment,inp=[tf.cast(cost_matrix, tf.float32)],Tout=[tf.int32])

def tf_linear_sum_assignment_batch(cost_matrix): # (100, num_box, 22)
    def np_linear_sum_assignment(cost_matrix):
        return np.array([linear_sum_assignment(cm, maximize=False)[1].astype(np.int32) for cm in cost_matrix])
    return tf.numpy_function(func=np_linear_sum_assignment,inp=[tf.cast(cost_matrix, tf.float32)],Tout=[tf.int32])





#"""
# @tf.function(input_signature=(tf.TensorSpec(shape=[None, None, 3], dtype=tf.float32),
#                               tf.TensorSpec(shape=[None, None, 3], dtype=tf.float32),
#                               tf.TensorSpec(shape=[None], dtype=tf.bool),
#                               tf.TensorSpec(shape=[None, None], dtype=tf.float32),
#                               tf.TensorSpec(shape=[None, 4, 1], dtype=tf.float32),
#                               tf.TensorSpec(shape=[], dtype=tf.int32),
#                               tf.TensorSpec(shape=[None], dtype=tf.float32),
#                               tf.TensorSpec(shape=[None], dtype=tf.float32),
#                               tf.TensorSpec(shape=[None], dtype=tf.float32),
#                               tf.TensorSpec(shape=[None], dtype=tf.float32),
#                               #tf.TensorSpec(shape=[], dtype=tf.float32),
#                               #tf.TensorSpec(shape=[], dtype=tf.float32),
#                               #tf.TensorSpec(shape=[], dtype=tf.float32),
#                               #tf.TensorSpec(shape=[], dtype=tf.float32),
#                               tf.TensorSpec(shape=[], dtype=tf.int32),
#                               tf.TensorSpec(shape=[], dtype=tf.int32),
#                               )
#              )#"""
def icp_fitting_2d_batch_confdrop_cost(targets, sources, conf_mask, cost, l2_penalty, num_iter=20,
                   k = 0., rz = 0., tx = 0., ty = 0., 
                   
                   #k_penalty=1.0, rz_penalty=1.0, tx_penalty=1.0, ty_penalty=1.0,
                   num_harddrop=0, num_softdrop=0):

    # 如果4个变换的惩罚都是1，则l2_penalty_matrix中每次实验的4x4矩阵是一个单位阵
    l2_penalty_matrix = tf.eye(4)[tf.newaxis,...] * l2_penalty
    # (100, 4, 4) = (1, 4, 4) * (100, 4, 1)
    def get_transmatrix(k, rz, tx, ty):
        """
        k : zoom ratio.
        rz : rotation.
        tx : x offset.
        ty : z offset
        shape [batch]
        
        returns:
            transmatrix with shape [batch, 3, 3]
        
        #TODO add penalty on k
        #add penalty on rotation angle
        l2 norm系パラメータ調整？初期値からの乖離の方がいいかも
        
        """
        # 先旋转，再平移，最后缩放
        # 因为不对z轴即team坐标进行变换，所以4维齐次矩阵去除第三个列和第三行就变成了三维矩阵
        # 这里的矩阵最终与坐标相乘时需要进行转置，才会形成正确的变换矩阵
        # [cos,  sin,  0]   [1,  0,  0]   [exp_k,  0,      0]
        # [-sin, cos,  0]   [0,  1,  0]   [0,      exp_k,  0]
        # [0,    0,    1]   [tx, ty, 1]   [0,      0,      1]
        exp_k = tf.math.exp(k)
        sin = tf.math.sin(rz)
        cos = tf.math.cos(rz)
        mat = tf.stack([[exp_k*cos, -exp_k*sin, exp_k*tx],
                        [exp_k*sin, exp_k*cos, exp_k*ty],
                        [tf.zeros_like(k), tf.zeros_like(k), tf.ones_like(k)]]) # (3, 3, 100)
        mat = tf.transpose(mat, [2,0,1])
        return mat
        
    #def transform_points(transmatrix, points):
    #    x, y = tf.split(points, 2, axis=-1)
    #    xyones = tf.concat([x,y,tf.ones_like(x)], axis=-1)
    #    trans_points = tf.matmul(xyones, transmatrix, transpose_b=True)[...,:2]
    #    return trans_points
    
    #2->3 when use team
    def transform_points(transmatrix, points):
        # 在使得team标记不变的情况下，对xy进行坐标变换
        x, y, team = tf.split(points, 3, axis=-1)
        xyones = tf.concat([x,y,tf.ones_like(x)], axis=-1)
        trans_points = tf.matmul(xyones, transmatrix, transpose_b=True)[...,:2]#do not warp for team axis
        trans_points = tf.concat([trans_points, team], axis=-1)
        return trans_points
    
    def get_derivative_at(k, rz, tx, ty, points):
        # 分别求k, rz, tx, ty在original、传入的k, rz, tx, ty条件下的梯度
        # 以k为例，即k变化dirta，各个点xyz坐标的变化幅度
        dev = 1e-5
        original = transform_points(get_transmatrix(k, rz, tx, ty), points)
        dxy_dk = (transform_points(get_transmatrix(k+dev, rz, tx, ty), points) - original) / dev
        dxy_drz = (transform_points(get_transmatrix(k, rz+dev, tx, ty), points) - original) / dev
        dxy_dtx = (transform_points(get_transmatrix(k, rz, tx+dev, ty), points) - original) / dev
        dxy_dty = (transform_points(get_transmatrix(k, rz, tx, ty+dev), points) - original) / dev
        return original, dxy_dk, dxy_drz, dxy_dtx, dxy_dty
    
    def normal_equation(X, Y, gn_rate=1.0, gd_rate=0.02):  # (100, num_box*3, 4), (100, num_box*3, 1), rnt: (100, 4, 1)
        #l2_penalty = tf.stack([[[1.0 * k_penalty,
        #                         1.0 * rz_penalty,
        #                         1.0 * tx_penalty,
        #                         1.0 * ty_penalty]]])
        
        #not in use, 1.0/rz_penalty, 1.0/tx_penalty, 1.0/ty_penalty
        #Gaussian Neuton combind with Gradient descent
        XtX = tf.matmul(X, X, transpose_a=True) + l2_penalty_matrix # (100, 4, 4)
        
        #XtX_inv = np.linalg.inv(XtX)
        #XtX_inv = 1.0*XtX_inv + 0.5*np.eye(len(XtX))
        #results = np.dot(XtX_inv, np.dot(X.T, Y))
        
        results_neuton = tf.linalg.solve(XtX, tf.matmul(X, Y, transpose_a=True)) # (100, 4, 4), (100, 4, 1)
        #results_gaussian = tf.matmul(tf.tile(tf.eye(XtX.shape[1])[tf.newaxis,...], [XtX.shape[0],1,1]), tf.matmul(X, Y, transpose_a=True))
        #results_gaussian = tf.matmul(tf.eye(XtX.shape[0]), tf.matmul(X, Y, transpose_a=True))
        results = gn_rate*results_neuton# + gd_rate*results_gaussian # (100, 4, 1)
        
        return results
    
    def search_nearest_target(sources, targets, batch_size):
        #全てのsourceを使用するかどうか。linear sum assignmentがいいな。
        #行方向にsource,　列方向にtarget軸を持ってきて距離二乗値を入れる。
        dist_matrix = tf.reduce_sum((sources[:,:,tf.newaxis,:] - targets[:,tf.newaxis,:,:])**2, axis=-1)
        ##assignments = []
        ##assignment = tf.zeros((tf.shape(sources)[1]), tf.int32)
        ##for _ in tf.range(batch_size):
        ##    assignment = tf.reshape(tf_linear_sum_assignment(dist_matrix[i])[0], [tf.shape(sources)[1]])
        ##    assignments.append(assignment)
        #assignments = tf.tile(tf.range(tf.shape(sources)[1])[tf.newaxis,:], [tf.shape(sources)[0],1])
        
        #TODO  このアサインメントって距離二乗じゃなくて距離にすべきか？？？？
        #試してみる
        #dist_matrix = tf.math.sqrt(dist_matrix)
        assignments = tf_linear_sum_assignment_batch(dist_matrix)#[0]
        ##assignments = tf.stack(assignments)
        temp_targets = tf.gather(targets, assignments, batch_dims=1)
        #print(assignments)
        return temp_targets, assignments
    
    def search_nearest_target_drop(sources, targets, num_drop, additional_cost): # num_drop=0
        '''
        给定两组点云和代价矩阵，进行点与点的匹配问题
        返回的temp_targets和temp_sources是点与点之间互相匹配的点坐标，assignments是点与点匹配关系
        assignments_valid是去除没能匹配上点以后的点与点匹配关系，其實完全等价于assignments
        not_pad_mask对应assignments，匹配上的为True，没匹配上的为False；其实全为True
        '''
        #全てのsourceを使用するかどうか。linear sum assignment　全てアサインする必要が無いバージョン。
        #行方向にsource,　列方向にtarget軸を持ってきて距離二乗値を入れる。
        #target軸方向にゼロパッドすることで、アサインしにくいソースを捨てる。
        #TODO 最終で増やしても変わらないところを見定めるのにも使いたい。
        batch, num_targets, _ = tf.unstack(tf.shape(targets))
        batch, num_sources, _ = tf.unstack(tf.shape(sources))
        
        ##SORCES MUST BE SORTED BY CONFIDENCE
        ##num_pad = tf.minimum(num_lessconf, num_drop)
        num_can_drop = tf.minimum(num_sources, num_lessconf)
        no_cost_pad = tf.concat([tf.ones((batch,num_sources-num_can_drop,num_drop), tf.float32),
                                 tf.zeros((batch,num_can_drop,num_drop), tf.float32)],
                                 axis=1)
        # dist_matrix (100, num_box, 22)，100次实验的每次实验中sources[i]相对targets[j]的距离
        dist_matrix = tf.reduce_sum((sources[:,:,tf.newaxis,:] - targets[:,tf.newaxis,:,:])**2, axis=-1)
        dist_matrix = additional_cost + dist_matrix
        #dist_matrix_pad = tf.pad(dist_matrix, [[0,0],[0,0],[0,num_pad]], "CONSTANT")
        dist_matrix_pad = tf.concat([dist_matrix, no_cost_pad], axis=-1)
        assignments = tf_linear_sum_assignment_batch(dist_matrix_pad)#[0] # 指派 (100, num_box)
        
        assignments = tf.reshape(assignments, [batch, num_sources]) # (100, num_box)
        not_pad_mask = (assignments < num_targets)  # 應該都為True
        
        
        #assignments = tf.boolean_mask(assignments, not_pad_mask)
        assignments_valid = tf.reshape(tf.boolean_mask(assignments, not_pad_mask), [batch, num_sources-num_drop])
        temp_targets = tf.gather(targets, assignments_valid, batch_dims=1)
        #temp_targets = tf.reshape(temp_targets, [batch, num_targets, -1])
        #temp_targets_mask = tf.boolean_mask(temp_targets, not_pad_mask, axis=1)
        temp_sources = tf.boolean_mask(sources, not_pad_mask)
        temp_targets = tf.reshape(temp_targets, [batch, num_sources-num_drop, -1]) # (100, num_box, 3)
        temp_sources = tf.reshape(temp_sources, [batch, num_sources-num_drop, -1]) # (100, num_box, 3)
        #print(assignments_valid.shape)
        #print(assignments.shape)
        """
        source_idx = tf.tile(tf.range(num_sources)[tf.newaxis,:], [batch_size, 1])
        target_idx = tf.tile(tf.range(num_targets)[tf.newaxis,:], [batch_size, 1])
        pad_mask = assignments >= num_targets
        assigned_idx_source
        not_assigned_idx_source
        assigned_idx_target
        not_assigned_idx_target
        
        target_idx = tf.cast(tf.range(t_num_points)[tf.newaxis,:,tf.newaxis], tf.float32)
        assigned_index = tf.cast(assignments, tf.float32)[:,tf.newaxis,:]
        #dev_index = tf.boolean_mask(tf.tile(base_index[:,:,0],[batch,1]), tf.reshape(tf.reduce_min((base_index - assigned_index)**2, axis=-1)>0.1, [batch, t_num_points]))
        dev_index = tf.boolean_mask(tf.tile(base_index[:,:,0],[batch,1]), tf.reshape(tf.reduce_all(base_index != assigned_index, axis=-1), [batch, t_num_points]))
        not_assigned_idx_target = tf.reshape(tf.cast(dev_index, tf.int32), [batch, -1])
        targets_remain = tf.gather(targets, not_assigned_idx_target, batch_dims=1)
        """
        
        return temp_targets, temp_sources, assignments, assignments_valid, not_pad_mask
    
    def final_search_nearest_target_drop(sources, targets, num_drop, additional_cost): # num_drop=0
        # 返回的targets_assigned是成功匹配的targets点坐标
        # sources_assigned是成功匹配的sources点坐标
        # targets_remain是未能成功匹配的targets点坐标
        # sources_remain是未能成功匹配的sources点坐标
        # assigned_idx_target_valid是成功匹配的targets序号
        # assigned_idx_source是成功匹配的sources序号
        # not_assigned_idx_target是没能成功匹配的targets点序号
        # not_assigned_idx_source是没能成功匹配的sources点序号
        #全てのsourceを使用するかどうか。linear sum assignment　全てアサインする必要が無いバージョン。
        #行方向にsource,　列方向にtarget軸を持ってきて距離二乗値を入れる。
        #target軸方向にゼロパッドすることで、アサインしにくいソースを捨てる。
        #TODO 最終で増やしても変わらないところを見定めるのにも使いたい。
        """
        dist_matrix = tf.reduce_sum((sources[:,:,tf.newaxis,:] - targets[:,tf.newaxis,:,:])**2, axis=-1)
        dist_matrix_pad = tf.pad(dist_matrix, [[0,0],[0,0],[0,num_drop]], "CONSTANT")
        assignments = tf_linear_sum_assignment_batch(dist_matrix_pad)[0]
        temp_targets = tf.gather(targets, assignments, batch_dims=1)
        not_pad_mask = (assignments < num_targets)
        temp_targets = tf.boolean_mask(temp_targets, not_pad_mask, axis=1)
        temp_sources = tf.boolean_mask(sources, not_pad_mask, axis=1)
        """
        batch, num_targets, _ = tf.unstack(tf.shape(targets))
        batch, num_sources, _ = tf.unstack(tf.shape(sources))

        targets_assigned, sources_assigned, assigned_idx_target, assigned_idx_target_valid, not_pad_mask = search_nearest_target_drop(sources, targets, num_drop, additional_cost)

        not_pad_mask = (assigned_idx_target < num_targets)
        pad_mask = (assigned_idx_target >= num_targets)
        source_idx = tf.tile(tf.range(num_sources)[tf.newaxis,:], [batch, 1]) # (100, num_box)
        #target_idx = tf.tile(tf.range(num_targets)[tf.newaxis,:], [batch, 1])
        #print(source_idx.shape, not_pad_mask.shape)
        assigned_idx_source = tf.boolean_mask(source_idx, not_pad_mask)#, axis=1)
        not_assigned_idx_source = tf.boolean_mask(source_idx, pad_mask)#, axis=1)
        assigned_idx_source = tf.reshape(assigned_idx_source, [batch, num_sources-num_drop]) # (100, num_box)，成功匹配的source idx
        # 每次实验中，有对应点的source点序号
        not_assigned_idx_source = tf.reshape(not_assigned_idx_source, [batch, num_drop]) # 未能成功匹配的source idx
        # 每次实验中，没有对应点的source点序号
        #assigned_idx_target = 
        #not_assigned_idx_target
        
        target_idx = tf.cast(tf.range(num_targets)[tf.newaxis,:,tf.newaxis], tf.float32) # (1, 22, 1)
        assigned_index = tf.cast(assigned_idx_target, tf.float32)[:,tf.newaxis,:] # (100, 1, num_box)
        dev_index = tf.boolean_mask(tf.tile(target_idx[:,:,0],[batch,1]), tf.reshape(tf.reduce_all(target_idx != assigned_index, axis=-1), [batch, num_targets]))
        # tf.reduce_all(target_idx != assigned_index, axis=-1), 每次实验时得到的矩阵是(22, 20)，逐行看，只要该行出现一个相等，该行就为F；否则该行为T
        # tf.reduce_all(target_idx != assigned_index, axis=-1) 得到(100, 22)，对应每个实验中，target 22个点中哪些没有source对应
        not_assigned_idx_target = tf.reshape(tf.cast(dev_index, tf.int32), [batch, -1])
        # not_assigned_idx_target：(100, 22-num_box)，对应每次实验中，没被匹配上的target点序号

        sources_remain = tf.gather(sources, not_assigned_idx_source, batch_dims=1)
        targets_remain = tf.gather(targets, not_assigned_idx_target, batch_dims=1)
        #print(sources_remain)
        #print(targets_remain)
        return targets_assigned, sources_assigned, targets_remain, sources_remain, assigned_idx_target_valid, assigned_idx_source, not_assigned_idx_target, not_assigned_idx_source
    
    def get_current_location(k, rz, tx, ty, sources): # sources: (100, num_box, 3)
        trans_matrix = get_transmatrix(k, rz, tx, ty) # (100, 3, 3)
        current = transform_points(trans_matrix, sources)
        return current
    
    
    
    
    batch, num_targets, _ = tf.unstack(tf.shape(targets))
    batch, num_sources, _ = tf.unstack(tf.shape(sources))

    # 将初始(num_box, 22)的全0矩阵扩展到100个实验
    cost = tf.tile(cost[tf.newaxis,:,:],[batch,1,1]) # (100, num_box, 22)
    num_lessconf = tf.reduce_sum(1 - tf.cast(conf_mask,tf.int32)) # sources中conf小于等于0.4的bbox的数量
    

    sources_original = sources
    batch, num_points, _ = tf.unstack(tf.shape(sources))
    
    #k = 0.#0 * tf.ones((batch), tf.float32)#expで取る。ネガティブでんし。
    #rz = 0.#0 * tf.ones((batch), tf.float32)
    #tx = 0.#0 * tf.ones((batch), tf.float32)
    #ty = 0.#0 * tf.ones((batch), tf.float32)
    #limit_updates = 1.0 * tf.ones((1,1),tf.float32)
    ##not using
    ##limit_updates = tf.stack([[1.0/k_penalty, 1.0/rz_penalty, 1.0/tx_penalty, 1.0/ty_penalty]])
    #limit_updates = tf.stack([[1.0, 1.0, 1.0, 1.0]])/rz_penalty
    ##limit_updates = tf.tile(limit_updates, [batch, 1])
    ##num_top = num_points-(num_points//10)

    drop_during_iter = num_harddrop + num_softdrop
    drop_during_iter = tf.minimum(num_lessconf, drop_during_iter) # 0
    drop_final = tf.minimum(num_lessconf, num_harddrop) # 0
    # CONFIDENCE THresh MUST BE ENOUGH LARGE. if too small, even hard drop will not work 
    for i in range(num_iter):
        
        current = get_current_location(k, rz, tx, ty, sources)  # (100, num_box, 3)
        temp_targets, _, _, _, not_pad_mask = search_nearest_target_drop(current, targets, drop_during_iter, cost)

        #temp_targets, _ = search_nearest_target(current, targets, batch)
        #print(_)
        temp_sources = tf.boolean_mask(sources, not_pad_mask)
        temp_sources = tf.reshape(temp_sources, [batch, num_sources-drop_during_iter, -1]) # 等价于原始sources
        ##temp_targets, _ = search_nearest_target(sources, targets, batch_size)
        currents, dxy_dk, dxy_rz, dxy_dtx, dxy_dty = get_derivative_at(k, rz, tx, ty, temp_sources)
        delta = temp_targets - currents
        """
        
        current = get_current_location(k, rz, tx, ty, sources)
        temp_targets, _ = search_nearest_target(current, targets, batch_size)
        ##temp_targets, _ = search_nearest_target(sources, targets, batch_size)
        currents, dxy_dk, dxy_rz, dxy_dtx, dxy_dty = get_derivative_at(k, rz, tx, ty, sources)
        delta = temp_targets-currents        
        #"""
        
        #nonlinear weight by distance
        """
        distance = tf.math.sqrt(tf.reduce_sum(delta[...,:2]**2, axis=-1, keepdims=True))
        weight = distance/tf.reduce_mean(distance, axis=1, keepdims=True)
        weight = 1.0 / tf.maximum(weight, 1.0)#平均より遠い場合はウェイト下げる
        
        #and条件ある方がいいかな。0.1distance以上とか。 あと、今フラットさちりなので、ノンリニア化する。
        b = tf.reshape(delta * weight, [-1, num_points*3, 1])#x-y-team flatten
        a = tf.stack([dxy_dk, dxy_rz, dxy_dtx, dxy_dty], axis=-1)
        a = tf.reshape(a * weight[...,tf.newaxis], [-1, num_points*3, 4])
        """
        #a = tf.reshape(a, [-1, num_points*3, 4])
        # b为sources经过这轮变换后相对targets的距离
        # a为四种变换在sources经过这轮变换后位置处的梯度
        b = tf.reshape(delta, [-1, (num_points-drop_during_iter)*3, 1])#x-y-team flatten (100, num_box*3, 1)
        a = tf.stack([dxy_dk, dxy_rz, dxy_dtx, dxy_dty], axis=-1)
        a = tf.reshape(a, [-1, (num_points-drop_during_iter)*3, 4]) # (100, num_box*3, 4)
        
        
        
        """
        # use top k
        #　この時点でtopkとるよりも、linear assignmentのタイミングで、これ除けば楽なのに…。というやつを見つけるほうがいい気がする。
        # やっぱりランダムドロップ？？？
        distance = tf.reduce_sum(delta[...,:2]**2, axis=-1)
        values, indices = tf.math.top_k(-distance, k=num_top)
        delta = tf.gather(delta, indices, batch_dims=1)
        b = tf.reshape(delta, [-1, num_top*3, 1])#x-y-team flatten
        a = tf.stack([dxy_dk, dxy_rz, dxy_dtx, dxy_dty], axis=-1)
        a = tf.gather(a, indices, batch_dims=1)
        a = tf.reshape(a, [-1, num_top*3, 4])
        """
        
        #delta_dist = tf.reduce_sum(delta**2, axis=-1, keepdims=True)
        #delta_base_weight = tf.reshape(tf.tile(tf.reduce_mean(delta_dist)/(delta_dist)+1e-20, [1,2]), [num_points*2, 1])
        #a *= delta_base_weight
        #b *= delta_base_weight
        
        #updates = tf.linalg.lstsq(a, b, l2_regularizer=0.01, fast=True)#batch, 4, 1
        updates = normal_equation(a,b)#[:,:,0]  (100, num_box*3, 4), (100, num_box*3, 1), rnt: (100, 4, 1)
        updates = tf.reshape(updates, [batch, 4])
        #print(updates)
        #clip update
        #max_update = tf.math.abs(tf.reduce_max(updates, axis=2, keepdims=True))
        
        ##updates_ratio = tf.reduce_min(limit_updates / (tf.math.abs(updates)+1e-12), axis=1, keepdims=True)
        ##updates = updates * tf.minimum(updates_ratio, tf.ones_like(updates_ratio))
        
        #print(updates)
        
        k = k + updates[:,0]
        rz = rz + updates[:,1]
        tx = tx + updates[:,2]
        ty = ty + updates[:,3]

    # 得到最终的k、rz、tx、ty，进行变换
    trans_matrix = get_transmatrix(k, rz, tx, ty)
    trans_sources = transform_points(trans_matrix, sources)
    targets_assigned, sources_assigned, targets_remain, sources_remain, assigned_idx_target, assigned_idx_source, not_assigned_idx_target, not_assigned_idx_source = final_search_nearest_target_drop(trans_sources, targets, drop_during_iter, cost)
    
    #B, N, M and B, n -> B, n, M
    #B, n, M and B, m -> B, n, m
    cost_remain = tf.gather(cost, not_assigned_idx_source, batch_dims=1) # (100, 0, 22)
    cost_remain = tf.transpose(cost_remain, [0,2,1])  # (100, 22, 0)
    cost_remain = tf.gather(cost_remain, not_assigned_idx_target, batch_dims=1)
    cost_remain = tf.transpose(cost_remain, [0,2,1])  # (100, 0, 2)
    # cost_remain是没能成功匹配的sources点序号与targets点序号共同组成的代价矩阵
    
    targets_reassigned, sources_reassigned, _as, assignments_valid, not_pad_mask = search_nearest_target_drop(sources_remain, targets_remain, drop_final, cost_remain)
    ###_, remain_assignments = search_nearest_target(sources_remain, targets_remain, batch)
    ###remain_assignments = tf.gather(not_assigned_idx_target, remain_assignments, batch_dims=1)
    remain_assignments = tf.gather(not_assigned_idx_target, assignments_valid, batch_dims=1) # 从未能匹配的targets 序号中取到重匹配成功的序号
    
    
    #mean 間違ってる…。
    #residual_assigned = tf.reduce_mean((targets_assigned - sources_assigned)**2, axis=[1,2])
    # 原始匹配的每组实验中，源点与目标点三维距离平方的均值，(100, )
    residual_assigned = tf.reduce_mean(tf.reduce_sum((targets_assigned - sources_assigned)**2, axis=2), axis=1)
    # 原始匹配的每组实验中的每对匹配，源点与目标点二维距离平方值， (100, num_box)
    residual_assigned_xy = tf.reduce_sum((targets_assigned[...,:2] - sources_assigned[...,:2])**2, axis=2)
    # 重匹配的每组实验中，每对匹配源点与目标点二维距离的平方值, (100, num_box)
    residual_reassigned_xy = tf.reduce_sum((targets_reassigned[...,:2] - tf.reshape(sources_reassigned[...,:2], [batch,-1,2]))**2, axis=2)
    
    final_assignments_unsort = tf.concat([assigned_idx_target, remain_assignments], axis=1) # 首次匹配+重匹配后得到最终成功匹配的targets序号
    argsort_source_all = tf.argsort(tf.concat([assigned_idx_source, not_assigned_idx_source], axis=1), axis=1) # 所有sources的序号
    not_assigned_idx_source = tf.reshape(tf.boolean_mask(not_assigned_idx_source, not_pad_mask),[batch,-1]) # 求首轮没能匹配上的sources点中在重匹配中成功匹配的序号
    argsort_source = tf.argsort(tf.concat([assigned_idx_source, not_assigned_idx_source], axis=1), axis=1) # 首次匹配+重匹配后得到最终成功匹配的排序后sources序号
    source_selection = tf.concat([tf.ones_like(assigned_idx_source), tf.cast(not_pad_mask,tf.int32)], axis=1) # 首次匹配+重匹配后最终成功匹配的sources为1，否则为0
    residual_xy = tf.concat([residual_assigned_xy, residual_reassigned_xy], axis=1) # 两次匹配的残差 （100,2num_box）
    final_assignments = tf.gather(final_assignments_unsort, argsort_source, batch_dims=1)
    source_selection = tf.gather(source_selection, argsort_source_all, batch_dims=1)
    residual_xy = tf.gather(residual_xy, argsort_source, batch_dims=1)
    
    residual = residual_assigned
    raw_results = [k, rz, tx, ty]
    #print(trans_matrix)
    # 变换后的最终sources点集
    # 最终的变换矩阵
    # 原始匹配的每组实验中，源点与目标点三维距离平方的均值
    # 。。
    # [k, rz, tx, ty]
    # 。。
    # 。。
    return trans_sources, trans_matrix, residual, final_assignments, raw_results, source_selection, residual_xy






if __name__ == "__main__":


    targets = tf.constant([[3.8095002, 1.326    ],
       [3.5814998, 2.1895   ],
       [3.8330002, 1.45     ],
       [3.5740001, 1.602    ],
       [3.5265   , 1.3305   ],
       [3.5485   , 1.404    ],
       [3.5595002, 1.1665   ],
       [3.543    , 1.474    ],
       [3.5630002, 1.2455   ],
       [3.529    , 1.5465   ],
       [3.5665002, 1.1      ],
       [3.1430001, 1.075    ],
       [3.4245   , 2.2129998],
       [3.4494998, 1.008    ],
       [2.7285   , 1.523    ],
       [3.221    , 1.334    ],
       [3.2610002, 1.181    ],
       [3.2755   , 1.5189999],
       [3.456    , 1.1905   ],
       [3.4435   , 1.5395   ],
       [3.4575   , 1.293    ],
       [3.4505   , 1.4075   ]], dtype=tf.float32)
    sources = tf.constant([[ 2.70448804e-01, -2.93340623e-01],
       [ 2.31210589e-01,  1.18682384e-01],
       [ 3.26063991e-01,  1.16790533e-02],
       [ 3.67939472e-04, -2.29702473e-01],
       [ 1.51242316e-01,  5.33789396e-03],
       [-1.78038955e-01, -1.72568381e-01],
       [-7.24216104e-02,  1.21840239e-02],
       [-1.97002888e-01, -7.43742347e-01],
       [ 1.02059245e-02,  7.97274113e-02],
       [-1.39494061e-01,  9.11870003e-02],
       [-2.69900054e-01,  1.24573708e-01],
       [-6.94324374e-02,  9.58986282e-02],
       [ 1.63274407e-01,  1.02119088e-01],
       [ 4.17458415e-02,  9.84644890e-03],
       [ 1.56390429e-01, -1.92121506e-01],
       [-1.99530929e-01,  1.87988281e-02],
       [ 8.68455768e-02,  1.16788030e-01],
       [-1.15765184e-01,  4.00170684e-01],
       [ 9.52500105e-03,  3.57541323e-01],
       [-2.05733836e-01,  8.69452953e-02]], dtype=tf.float32)
    team_labels = tf.constant([[1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [1.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.],
       [0.]], dtype=tf.float32)
    pred_team = tf.constant([[0.01323869],
       [0.9889387 ],
       [0.01143676],
       [0.010489  ],
       [0.01073981],
       [0.01038879],
       [0.01158138],
       [0.01037947],
       [0.98930347],
       [0.98862076],
       [0.9885255 ],
       [0.98955715],
       [0.98895836],
       [0.01733881],
       [0.00968699],
       [0.01398322],
       [0.98884016],
       [0.9891932 ],
       [0.9889958 ],
       [0.98867387]], dtype=tf.float32)
    team_provided=False
    confidence = tf.constant([0.72075546, 0.7016457 , 0.69784504, 0.6976857 , 0.690495  ,
       0.65974885, 0.65632546, 0.64912784, 0.6451626 , 0.64116347,
       0.62827957, 0.62459993, 0.61775196, 0.60695004, 0.59780955,
       0.5863977 , 0.5823457 , 0.57605094, 0.55293816, 0.39343444])
    confidence_threshold = 0.4
    use_provided_params = tf.constant(False)
    rz_params = tf.ones((3), tf.float32)
    txy_params = tf.ones((2, 3), tf.float32)
    zoom_params = tf.ones((3), tf.float32)
    temp= {"use_provided_params": use_provided_params,
                            "rz_params": rz_params,
                            "txy_params": txy_params,
                            "zoom_params": zoom_params,
                            "use_random_params": tf.constant(True),
                            }
    rnt = make_icp_inputs(targets=targets,
                    sources=sources,
                    targets_team=team_labels,
                    sources_team=pred_team,
                    team_provided=team_provided,
                    confidence=confidence,
                    confidence_threshold=0.4,
                    num_trial=100,
                    is_sideline=False,
                    **temp)
    results = random_icp_fitting(*rnt,
                                 st_cost_matrix=np.zeros((len(sources), len(targets)), np.float32),
                                 num_fitting_iter=8,
                                 num_harddrop=0,
                                 num_softdrop=0)
    print(results)
    # targets = tf.constant([[0,0],
    #                        [1,0.1],
    #                        [2,0],
    #                        [3,0.25],
    #                        [4,0],
    #                        [2,2],
    #                        [1.3,1.6],
    #                        [1.3,-1.3]], tf.float32)
    # sources = targets[:6]*0.5 + 0.00001-0.5
    #
    # targets_team = tf.constant([[0.05],
    #                        [1.0],
    #                        [2.0],
    #                        [3.25],
    #                        [4.0],
    #                        [1.2],
    #                        [3.3],
    #                        [1.2],
    #                        ], tf.float32)
    # sources_team = targets_team[:6]
    # # must be sorted
    # confidence = tf.constant([0.3,0.2,0.15,0.15,0.05,0.04], tf.float32)
    #
    #     #current_redisual, current_matrix, current_sources, current_assignment, current_raw_results
    # #results = random_icp_fitting_batch(targets,
    # #                   sources,
    # #                   confidence,
    # #                   targets_team,
    # #                   sources_team,
    # #                   num_trial=2,
    # #                   )
    # confidence_threshold = 0.1
    # num_harddrop = 1
    #
    # results = random_icp_fitting_batch_drop_cost(targets[:6],
    #                    sources,
    #                    confidence,
    #                    targets_team[:6],
    #                    sources_team,
    #                    st_cost_matrix=tf.zeros((len(sources_team), 6), tf.float32),
    #                    num_trial=2,
    #                    #use_provided_params=True,
    #                    #txy_params = tf.constant([[0,0,100.],[0,0,100.]], tf.float32),
    #                    confidence_threshold=confidence_threshold,
    #                    num_harddrop=num_harddrop)
    # print("OK", results[0])
    # print(results[2])
    # print(results[3])
    # print(results[-1])
    # plt.scatter(targets[:,0],targets[:,1])
    # plt.scatter(results[2][:,0],results[2][:,1])
    # plt.show()
    # raise Exception("e")
    #
    # """
    # matrix = tf.constant([[0.5,0.2,0.6,0.8],
    #                       [0.1,0.3,0.4,0.2],
    #                       [0.6,0.6,0.2,0.3]])
    # assignment = tf_linear_sum_assignment(matrix)
    # print(assignment)
    # """
    #
    # """
    # targets = tf.constant([[0,0],
    #                        [1,0.1],
    #                        [2,0],
    #                        [3,0.25],
    #                        [4,0],
    #                        [2,2],
    #                        [1.3,1.6],
    #                        [1.3,-1.3]], tf.float32)
    # sources = targets[:5]*0.8 + 0.6
    #
    # #trans_sources, trans_matrix, residual, assigned_targets = icp_fitting_2d(targets, sources, num_iter=20, rz=0.7)
    # #print(trans_sources, residual, assigned_targets)
    #
    # print(icp_fitting_2d(targets, sources))
    #
    # random_icp_fitting(targets, sources, num_trial=30)
    # """
    #
    #
    # print("-"*10)
    # targets = tf.constant([[0,0],
    #                        [1,0],
    #                        [2,0],
    #                        [3,0],
    #                        [4,0],
    #                        [1,1],
    #                        [2,1],
    #                        [3,1],
    #                        ], tf.float32)
    # sources = targets[:5]*0.2 + 0.1
    #
    # trans_sources, trans_matrix, residual, final_assignment, raw_results = icp_fitting_2d(targets, sources, num_iter=1)
    # plt.scatter(trans_sources[:,0],trans_sources[:,1])
    # plt.scatter(targets[:,0],targets[:,1])
    # plt.show()
    # trans_sources, trans_matrix, residual, final_assignment, raw_results = icp_fitting_2d(targets, sources, num_iter=2)
    # plt.scatter(trans_sources[:,0],trans_sources[:,1])
    # plt.scatter(targets[:,0],targets[:,1])
    # plt.show()
    # trans_sources, trans_matrix, residual, final_assignment, raw_results = icp_fitting_2d(targets, sources, num_iter=3)
    # plt.scatter(trans_sources[:,0],trans_sources[:,1])
    # plt.scatter(targets[:,0],targets[:,1])
    # plt.show()
    #
    # raise Exception("e")
    # import time
    # s = time.time()
    # for i in range(10):
    #     results = random_icp_fitting_batch(targets, sources, num_trial=30)
    #     print("TIME", time.time()-s)
    #
    # print(results["residual"])
    # print(results["final_assignment"])
    # s = results["trans_sources"].numpy()
    # plt.scatter(s[:,0],s[:,1])
    # plt.scatter(targets[:,0],targets[:,1])
    # plt.show()
    #
    # #"""
    # for _ in range(10):
    #     print("-"*10)
    #     targets = tf.constant([[0,0],
    #                            [1,0.1],
    #                            [2,0],
    #                            [3,0.25],
    #                            [4,0],
    #                            [2,2],
    #                            [1.3,1.6],
    #                            [1.3,-1.3]], tf.float32)
    #     sources = targets[:5]*0.8 + 0.6
    #
    #     random_icp_fitting(targets, sources, num_trial=30)
    #
    # print(time.time()-s)
    # #"""
